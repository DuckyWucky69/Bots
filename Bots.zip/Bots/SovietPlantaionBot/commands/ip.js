exports.run = (client, message, args) => {
    message.channel.send("We play on the RedBeret minecraft server. Play it on `beretmc.red` or join with the raw ip, `138.201.34.27:25561` it is a 1.15.2 server but you can join on almost any version.").catch(console.error);
}