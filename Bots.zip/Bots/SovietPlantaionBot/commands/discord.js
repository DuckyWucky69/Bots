exports.run = (client, message, args) => {
    message.channel.send("The Discord server of the minecraft server we are playing on is `https://discord.gg/XUdNAbY` please join to and do `b!apply` in bot commands to apply for minecraft server if you haven't already!").catch(console.error);
}