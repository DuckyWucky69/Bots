const Discord = require("discord.js");
const Enmap = require("enmap");
const fs = require("fs");

const client = new Discord.Client();
const config = require("./config.json");

client.config = config;

fs.readdir("./events/", (err, files) => {
    if (err) return console.error(err);
    files.forEach(file => {
      const event = require(`./events/${file}`);
      let eventName = file.split(".")[0];
      client.on(eventName, event.bind(null, client));
    });
  });

client.commands = new Enmap();

fs.readdir("./commands/", (err, files) => {
  if (err) return console.error(err);
  files.forEach(file => {
    if (!file.endsWith(".js")) return;
    let props = require(`./commands/${file}`);
    let commandName = file.split(".")[0];
    console.log(`${commandName} Has been fully loaded and setup!`);
    client.commands.set(commandName, props);
  });
});

client.on("message", (message) => {
    if (message.content.startsWith("d-help")) {
        message.channel.send({embed: {
            color: 3447003,
            author: {
              name: client.user.username,
              icon_url: client.user.avatarURL
            },
            title: "Help",
            url: "http://duckduckgo.com",
            description: "This is the help page for this bot to show all of it's great and glorious commands!",
            fields: [{
                name: "d-help",
                value: "Brings you to this page!"
              },
              {
                name: "d-channel",
                value: "Shows you the channel link of the leader!"
              },
              {
                name: "d-report <user> <reason>",
                value: "Sends the report of the user with the specified reason to the admins!"
              },
              {
                name: "d-ticket <problem>",
                value: "Creates a ticket that gets sent straight to the admins!"
              },
              {
                name: "d-serverinfo",
                value: "Shows the info of the server!"
              },
              {
                name: "d-botinfo",
                value: "Shows the info of the bot!"
              },
              {
                name: "d-ping",
                value: "Shows the latency of the bot!"
              },
            ],
            timestamp: new Date(),
            footer: {
              icon_url: client.user.avatarURL,
              text: "© RockBot 2020"
            }
          }
        });
    }
    if (message.content.startsWith("d-staffhelp")) {
        message.channel.send({embed: {
            color: 3447003,
            author: {
              name: client.user.username,
              icon_url: client.user.avatarURL
            },
            title: "Staff Help",
            url: "http://google.com",
            description: "This is the staff help page for this bot to show all of it's great and glorious commands!",
            fields: [{
                name: "d-staff help",
                value: "Brings you to this page!"
              },
              {
                name: "d-kick <user> <reason>",
                value: "Kicks the specified user with the inputted reason."
              },
              {
                name: "d-ban <user> <reason>",
                value: "Bans the specified user with the inputted reason."
              },
              {
                name: "d-warn <user> <reason>",
                value: "Sends a DM to the specified user with the reason why they have been warned."
              },
              {
                name: "d-purge <amount>",
                value: "Deletes the number of messages you put inside <amount>!"
              },
              {
                name: "d-reload <commandName>",
                value: "Reloads the commands the bot has to work more efficiently! (owner only)"
              }
            ],
            timestamp: new Date(),
            footer: {
              icon_url: client.user.avatarURL,
              text: "© RockBot 2020"
            }
          }
        });
    }
    if (message.content === "d-ping"){
        message.channel.send('pong !').then(m => m.edit(`${message.author}:ping_pong: Pong! (Current latency is ${m.createdTimestamp - message.createdTimestamp}ms, while the API Latency is ${Math.round(client.ping)}ms)`) );
    }
  });
  client.on('message', msg => {
    const args = msg.content.slice(config.prefix.length).split(' ');
    const command = args.shift().toLowerCase();
    
    });

    client.on("error", (e) => console.error(e));
    client.on("warn", (e) => console.warn(e));
    client.on("debug", (e) => console.info(e));
    
client.login(config.token);