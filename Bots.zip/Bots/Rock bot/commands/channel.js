exports.run = (client, message, args) => {
    message.channel.send("Here is the lord's channel -> **https://www.youtube.com/channel/UCfbfofy0HI341eeRIU5t4NQ?view_as=subscriber**").catch(console.error);
}